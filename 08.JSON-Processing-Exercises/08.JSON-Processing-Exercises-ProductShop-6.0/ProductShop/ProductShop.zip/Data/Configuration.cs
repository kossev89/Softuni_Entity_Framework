﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-A4Q93F3\SQLEXPRESS;Database=ProductShop;Integrated Security=True";
    }
}
