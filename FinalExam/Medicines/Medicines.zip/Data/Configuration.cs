﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-A4Q93F3\SQLEXPRESS;Database=Medicines;Integrated Security=True;Encrypt=False";
    }
}
