﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boardgames.Data.Models.Enums
{
    public  enum CategoryType
    {
        Abstract,
        Children,
        Family,
        Party,
        Strategy
    }
}
