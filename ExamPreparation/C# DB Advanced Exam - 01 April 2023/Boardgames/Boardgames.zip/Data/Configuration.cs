﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-A4Q93F3\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
