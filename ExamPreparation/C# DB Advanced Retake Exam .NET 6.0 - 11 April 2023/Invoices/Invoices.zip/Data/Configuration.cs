﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-A4Q93F3\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
