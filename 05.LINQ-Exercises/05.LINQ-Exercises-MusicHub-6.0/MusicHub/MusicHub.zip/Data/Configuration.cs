﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-A4Q93F3\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True;Integrated Security=True";
    }
}
