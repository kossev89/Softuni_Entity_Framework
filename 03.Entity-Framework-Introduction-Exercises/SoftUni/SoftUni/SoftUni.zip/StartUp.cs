﻿using SoftUni.Data;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext softUniContext = new SoftUniContext();
            Console.WriteLine(Employee.GetEmployeesWithSalaryOver50000(softUniContext)); 
        }
    }
}